#include <iostream> 
#include <string>
#include <time.h> 

using namespace std;

class Person {
public: Person(){}
	   ~Person(){} 
	   string ID;
	   int value;
	   virtual void Display() {}
};

class gamerStu : public Person {
public: 
	gamerStu(string ID, int value) {
		this->ID = ID; 
		this->value = value; 
    } 
	~gamerStu() {}

	void Display() {
		cout << ID << ":value= " << value << endl;
	} 
};

class nongamerStu : public Person {
public:
	nongamerStu(string ID, int value) {
		this->ID = ID;
		this->value = value;
	}
	~nongamerStu() {}

	void Display() {
		cout << ID << " :value= " << value << endl;
	}
};

struct Survey {
	int gscount = 0, ngscount = 0, gsvalueTotal = 0, ngstotal = 0;
	float gsavg = 0.0f, ngsavg = 0.0f;
};

Survey* Process(Person* testArray[], int elements) {
	Survey* report = new Survey;
	for (int i = 0; i < elements; i++) {
		if (dynamic_cast<gamerStu*>(testArray[i])) {
			report->gscount++;
			report->gsvalueTotal += testArray[i]->value;
		}

		else if (dynamic_cast<nongamerStu*>(testArray[i])) {
			report->ngscount++;
			report->gsvalueTotal += testArray[i]->value;

		}
	}
	cout << " gamerStu: " << report->gscount << " instances\nnongamerStu: " << report->ngscount << " instances\n ";
	if (report->gscount != 0)
		report->gsavg = (float)report->gsvalueTotal / report->gscount;
	if (report->ngscount != 0)
		report->ngsavg = (float)report->gsvalueTotal / report->ngscount;

	return report;
}

Person* GenerateRandom() {
	Person* newObj;
	string	ID;
	int IDNum = rand() % 100000;
	if (rand() % 2) {
		ID = " gamerStu " + to_string(IDNum);
		newObj = new gamerStu(ID, rand() % 101);
	}
	cout << " Created newObj: ";
	newObj->Display();
	return newObj;
}

int main() {
	srand(time(NULL));
	Person* testArray[500];
	int elements = 500;
	for (int i = 0; i < elements; i++);
	testArray[500] = GenerateRandom();
	Survey* report = Process(testArray, elements);
	cout << "gamerStu avg value: " << report->gsavg << "\n nongamerStu avg value: " << report->ngsavg << endl;

	return 0;
};